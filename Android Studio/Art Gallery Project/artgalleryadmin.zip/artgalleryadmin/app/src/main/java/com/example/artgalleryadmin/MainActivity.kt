package com.example.artgalleryadmin

import android.Manifest.permission.READ_EXTERNAL_STORAGE
import android.R
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.example.artgalleryadmin.databinding.ActivityMainBinding
import net.gotev.uploadservice.MultipartUploadRequest

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    lateinit var filepath: Uri
    lateinit var  bitmap: Bitmap

    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        var data = arrayOf("select category","ColourFull Art","Black & White","Sketch")

        var adapter = ArrayAdapter(this, R.layout.simple_spinner_dropdown_item,data)
        binding.spinner.adapter=adapter

            if(checkSelfPermission(READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(this, arrayOf(READ_EXTERNAL_STORAGE),100)
            }
            else {
                Toast.makeText(applicationContext, "Permission alread granted", Toast.LENGTH_LONG)
                    .show()
            }

        binding.btnadd.setOnClickListener{
            var name = binding.edtpn.text.toString()
            var price = "Rs. " + binding.edtprice.text.toString()
            val path = getPath(filepath)
            var spin = when(binding.spinner.selectedItemPosition)
            {
                0->
                {

                }
                1->
                {
                    "ColourFull Art"
                }
                2->
                {
                    "Black & White"
                }
                3->
                {
                    "Sketch"
                }
                else->
                {
                    null
                }
            }
            val des = binding.edtdes.text.toString()

            MultipartUploadRequest(this,"https://mananviradia14.000webhostapp.com/art_gallery/product_add.php")
                .addFileToUpload(path, "url")
                .addParameter("product_name", name)
                .addParameter("product_price",price)
                .addParameter("product_des",des)
                .addParameter("product_category", spin.toString())
                .setMaxRetries(10)
                .startUpload()
            Toast.makeText(this@MainActivity, "success", Toast.LENGTH_SHORT).show()
        }

        binding.btnselect.setOnClickListener {
            var i = Intent()
            i.type = "image/*"
            i.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(Intent.createChooser(i, "Select Picture"), 1)
        }

    }

    @SuppressLint("Range")
    fun getPath(uri: Uri?): String
    {
        var cursor = contentResolver.query(uri!!, null, null, null, null)
        cursor!!.moveToFirst()
        var document_id = cursor.getString(0)
        document_id = document_id.substring(document_id.lastIndexOf(":") + 1)
        cursor.close()
        cursor = contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            null, MediaStore.Images.Media._ID + " = ? ", arrayOf(document_id), null)
        cursor!!.moveToFirst()
        val path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA))
        cursor.close()
        return path
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?)
    {
        if(requestCode==1 && resultCode == RESULT_OK && data != null)
        {

            filepath = data.data!!
            bitmap= MediaStore.Images.Media.getBitmap(contentResolver, filepath)
            binding.img.setImageBitmap(bitmap)

        }

        super.onActivityResult(requestCode, resultCode, data)
    }

}